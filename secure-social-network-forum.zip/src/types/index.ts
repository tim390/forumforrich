export interface User {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  createdAt: Date;
}

export interface Project {
  id: string;
  title: string;
  description: string;
  type: 'ai' | 'manual' | 'webapp';
  url?: string;
  imageUrl?: string;
  authorId: string;
  authorName: string;
  authorPhoto?: string;
  likes: string[];
  commentCount: number;
  createdAt: any;
}

export interface Comment {
  id: string;
  projectId: string;
  authorId: string;
  authorName: string;
  authorPhoto?: string;
  text: string;
  createdAt: Date;
}
