import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: "AIzaSyAOEcgxPS8fq58ahX7Q_jmVzc8J3pCMQaE",
  authDomain: "projecthub-625b8.firebaseapp.com",
  projectId: "projecthub-625b8",
  storageBucket: "projecthub-625b8.firebasestorage.app",
  messagingSenderId: "1001746465870",
  appId: "1:1001746465870:web:7722b212f63c05c104af1f",
  measurementId: "G-WGD0JXVZQ1"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize services
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);

export default app;
