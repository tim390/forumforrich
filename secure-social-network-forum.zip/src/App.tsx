import { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Auth } from './components/Auth';
import { Header } from './components/Header';
import { Feed } from './components/Feed';
import { NewProjectModal } from './components/NewProjectModal';

const AppContent = () => {
  const { currentUser } = useAuth();
  const [showNewProject, setShowNewProject] = useState(false);

  if (!currentUser) {
    return <Auth />;
  }

  if (!currentUser.emailVerified) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center p-4">
        <div className="bg-white/10 backdrop-blur-lg rounded-3xl shadow-2xl border border-white/20 p-8 max-w-md text-center">
          <h2 className="text-2xl font-bold text-white mb-4">Подтвердите email</h2>
          <p className="text-gray-300 mb-4">
            Мы отправили письмо с подтверждением на <strong>{currentUser.email}</strong>
          </p>
          <p className="text-gray-400 text-sm">
            Проверьте вашу почту и нажмите на ссылку подтверждения. После этого обновите страницу.
          </p>
          <button
            onClick={() => window.location.reload()}
            className="mt-6 bg-gradient-to-r from-purple-500 to-indigo-500 text-white px-6 py-3 rounded-xl font-semibold hover:from-purple-600 hover:to-indigo-600 transition-all"
          >
            Обновить страницу
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      <Header onNewProject={() => setShowNewProject(true)} />
      
      <main className="container mx-auto px-4 py-8">
        <Feed />
      </main>

      {showNewProject && (
        <NewProjectModal onClose={() => setShowNewProject(false)} />
      )}
    </div>
  );
};

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
