import { useEffect, useState } from 'react';
import { collection, query, where, orderBy, onSnapshot } from 'firebase/firestore';
import { db } from '../config/firebase';
import { Comment } from '../types';

interface CommentsProps {
  projectId: string;
}

export const Comments = ({ projectId }: CommentsProps) => {
  const [comments, setComments] = useState<Comment[]>([]);

  useEffect(() => {
    const q = query(
      collection(db, 'comments'),
      where('projectId', '==', projectId),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const commentsData: Comment[] = [];
      snapshot.forEach((doc) => {
        const data = doc.data();
        commentsData.push({
          id: doc.id,
          projectId: data.projectId,
          authorId: data.authorId,
          authorName: data.authorName,
          authorPhoto: data.authorPhoto,
          text: data.text,
          createdAt: data.createdAt?.toDate() || new Date()
        });
      });
      setComments(commentsData);
    });

    return unsubscribe;
  }, [projectId]);

  if (comments.length === 0) {
    return (
      <p className="text-gray-400 text-center py-4">Пока нет комментариев. Будьте первым!</p>
    );
  }

  return (
    <div className="space-y-4">
      {comments.map((comment) => (
        <div key={comment.id} className="flex space-x-3">
          {comment.authorPhoto ? (
            <img
              src={comment.authorPhoto}
              alt={comment.authorName}
              className="w-8 h-8 rounded-full flex-shrink-0"
            />
          ) : (
            <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-indigo-500 rounded-full flex items-center justify-center text-white text-sm font-bold flex-shrink-0">
              {comment.authorName[0]?.toUpperCase()}
            </div>
          )}
          <div className="flex-1">
            <div className="bg-white/5 rounded-xl p-3 border border-white/10">
              <p className="text-white font-semibold text-sm">{comment.authorName}</p>
              <p className="text-gray-300 mt-1">{comment.text}</p>
            </div>
            <p className="text-xs text-gray-500 mt-1 ml-3">
              {comment.createdAt.toLocaleDateString('ru-RU')} в {comment.createdAt.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
};
