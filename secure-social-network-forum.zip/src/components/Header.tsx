import { useAuth } from '../context/AuthContext';
import { FaRocket, FaSignOutAlt, FaPlus } from 'react-icons/fa';

interface HeaderProps {
  onNewProject: () => void;
}

export const Header = ({ onNewProject }: HeaderProps) => {
  const { currentUser, logout } = useAuth();

  return (
    <header className="bg-gradient-to-r from-purple-900 via-blue-900 to-indigo-900 border-b border-white/10 sticky top-0 z-50 backdrop-blur-lg bg-opacity-90">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <FaRocket className="text-4xl text-white" />
            <div>
              <h1 className="text-2xl font-bold text-white">ProjectHub</h1>
              <p className="text-sm text-gray-300">Делись своими проектами</p>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <button
              onClick={onNewProject}
              className="flex items-center space-x-2 bg-gradient-to-r from-purple-500 to-indigo-500 text-white px-6 py-3 rounded-xl font-semibold hover:from-purple-600 hover:to-indigo-600 transition-all shadow-lg hover:shadow-xl transform hover:scale-105"
            >
              <FaPlus />
              <span>Новый проект</span>
            </button>

            <div className="flex items-center space-x-3 bg-white/10 rounded-xl px-4 py-2 border border-white/20">
              {currentUser?.photoURL ? (
                <img
                  src={currentUser.photoURL}
                  alt={currentUser.displayName || 'User'}
                  className="w-10 h-10 rounded-full"
                />
              ) : (
                <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-indigo-500 rounded-full flex items-center justify-center text-white font-bold">
                  {currentUser?.displayName?.[0]?.toUpperCase() || 'U'}
                </div>
              )}
              <div className="hidden md:block">
                <p className="text-white font-semibold">{currentUser?.displayName}</p>
                <p className="text-xs text-gray-300">{currentUser?.email}</p>
              </div>
            </div>

            <button
              onClick={logout}
              className="flex items-center space-x-2 bg-red-500/20 text-red-300 px-4 py-3 rounded-xl hover:bg-red-500/30 transition-all border border-red-500/30"
              title="Выйти"
            >
              <FaSignOutAlt />
              <span className="hidden md:inline">Выйти</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
