import { useState } from 'react';
import { doc, updateDoc, arrayUnion, arrayRemove, collection, addDoc, serverTimestamp, increment } from 'firebase/firestore';
import { db } from '../config/firebase';
import { useAuth } from '../context/AuthContext';
import { Project } from '../types';
import { FaHeart, FaRegHeart, FaComment, FaRobot, FaCode, FaGlobe, FaExternalLinkAlt } from 'react-icons/fa';
import { Comments } from './Comments';

interface ProjectCardProps {
  project: Project;
}

export const ProjectCard = ({ project }: ProjectCardProps) => {
  const { currentUser } = useAuth();
  const [showComments, setShowComments] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const isLiked = currentUser ? project.likes.includes(currentUser.uid) : false;

  const handleLike = async () => {
    if (!currentUser) return;

    const projectRef = doc(db, 'projects', project.id);
    
    try {
      if (isLiked) {
        await updateDoc(projectRef, {
          likes: arrayRemove(currentUser.uid)
        });
      } else {
        await updateDoc(projectRef, {
          likes: arrayUnion(currentUser.uid)
        });
      }
    } catch (err) {
      console.error('Error updating like:', err);
    }
  };

  const handleComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !commentText.trim()) return;

    setSubmitting(true);
    try {
      await addDoc(collection(db, 'comments'), {
        projectId: project.id,
        authorId: currentUser.uid,
        authorName: currentUser.displayName || 'Аноним',
        authorPhoto: currentUser.photoURL || null,
        text: commentText,
        createdAt: serverTimestamp()
      });

      await updateDoc(doc(db, 'projects', project.id), {
        commentCount: increment(1)
      });

      setCommentText('');
    } catch (err) {
      console.error('Error adding comment:', err);
    } finally {
      setSubmitting(false);
    }
  };

  const getTypeIcon = () => {
    switch (project.type) {
      case 'ai':
        return <FaRobot className="text-purple-400" />;
      case 'manual':
        return <FaCode className="text-blue-400" />;
      case 'webapp':
        return <FaGlobe className="text-green-400" />;
    }
  };

  const getTypeLabel = () => {
    switch (project.type) {
      case 'ai':
        return 'AI проект';
      case 'manual':
        return 'Ручной код';
      case 'webapp':
        return 'Веб-сайт';
    }
  };

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20 overflow-hidden hover:shadow-2xl transition-all">
      {project.imageUrl && (
        <div className="relative h-64 overflow-hidden">
          <img
            src={project.imageUrl}
            alt={project.title}
            className="w-full h-full object-cover"
            onError={(e) => {
              e.currentTarget.src = 'https://via.placeholder.com/800x400/667eea/ffffff?text=' + encodeURIComponent(project.title);
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
        </div>
      )}

      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            {project.authorPhoto ? (
              <img
                src={project.authorPhoto}
                alt={project.authorName}
                className="w-10 h-10 rounded-full"
              />
            ) : (
              <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-indigo-500 rounded-full flex items-center justify-center text-white font-bold">
                {project.authorName[0]?.toUpperCase()}
              </div>
            )}
            <div>
              <p className="text-white font-semibold">{project.authorName}</p>
              <p className="text-xs text-gray-400">
                {project.createdAt?.toDate?.()?.toLocaleDateString('ru-RU')}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2 bg-white/10 px-3 py-1 rounded-full">
            {getTypeIcon()}
            <span className="text-sm text-white">{getTypeLabel()}</span>
          </div>
        </div>

        <h3 className="text-2xl font-bold text-white mb-2">{project.title}</h3>
        <p className="text-gray-300 mb-4 line-clamp-3">{project.description}</p>

        {project.url && (
          <a
            href={project.url}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center space-x-2 text-purple-400 hover:text-purple-300 mb-4"
          >
            <FaExternalLinkAlt />
            <span>Открыть проект</span>
          </a>
        )}

        <div className="flex items-center space-x-4 pt-4 border-t border-white/10">
          <button
            onClick={handleLike}
            className={`flex items-center space-x-2 transition-all ${
              isLiked ? 'text-red-500' : 'text-gray-400 hover:text-red-500'
            }`}
          >
            {isLiked ? <FaHeart className="text-xl" /> : <FaRegHeart className="text-xl" />}
            <span className="font-semibold">{project.likes.length}</span>
          </button>

          <button
            onClick={() => setShowComments(!showComments)}
            className="flex items-center space-x-2 text-gray-400 hover:text-blue-400 transition-all"
          >
            <FaComment className="text-xl" />
            <span className="font-semibold">{project.commentCount}</span>
          </button>
        </div>

        {showComments && (
          <div className="mt-6 pt-6 border-t border-white/10">
            <form onSubmit={handleComment} className="mb-4">
              <div className="flex space-x-2">
                <input
                  type="text"
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  placeholder="Написать комментарий..."
                  className="flex-1 bg-white/10 border border-white/20 rounded-xl py-2 px-4 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
                <button
                  type="submit"
                  disabled={submitting || !commentText.trim()}
                  className="bg-gradient-to-r from-purple-500 to-indigo-500 text-white px-6 py-2 rounded-xl font-semibold hover:from-purple-600 hover:to-indigo-600 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {submitting ? '...' : 'Отправить'}
                </button>
              </div>
            </form>

            <Comments projectId={project.id} />
          </div>
        )}
      </div>
    </div>
  );
};
