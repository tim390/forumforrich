import { useEffect, useState } from 'react';
import { collection, query, orderBy, onSnapshot } from 'firebase/firestore';
import { db } from '../config/firebase';
import { Project } from '../types';
import { ProjectCard } from './ProjectCard';
import { FaRocket } from 'react-icons/fa';

export const Feed = () => {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(
      collection(db, 'projects'),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const projectsData: Project[] = [];
      snapshot.forEach((doc) => {
        const data = doc.data();
        projectsData.push({
          id: doc.id,
          title: data.title,
          description: data.description,
          type: data.type,
          url: data.url,
          imageUrl: data.imageUrl,
          authorId: data.authorId,
          authorName: data.authorName,
          authorPhoto: data.authorPhoto,
          likes: data.likes || [],
          commentCount: data.commentCount || 0,
          createdAt: data.createdAt
        });
      });
      setProjects(projectsData);
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-center">
          <FaRocket className="text-6xl text-white animate-bounce mx-auto mb-4" />
          <p className="text-white text-xl">Загрузка проектов...</p>
        </div>
      </div>
    );
  }

  if (projects.length === 0) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-center">
          <FaRocket className="text-6xl text-white mb-4 mx-auto opacity-50" />
          <p className="text-white text-xl mb-2">Пока нет проектов</p>
          <p className="text-gray-400">Создайте первый проект и поделитесь им с миром!</p>
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {projects.map((project) => (
        <ProjectCard key={project.id} project={project} />
      ))}
    </div>
  );
};
