import { useState } from 'react';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../config/firebase';
import { useAuth } from '../context/AuthContext';
import { FaTimes, FaRobot, FaCode, FaGlobe } from 'react-icons/fa';

interface NewProjectModalProps {
  onClose: () => void;
}

export const NewProjectModal = ({ onClose }: NewProjectModalProps) => {
  const { currentUser } = useAuth();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [type, setType] = useState<'ai' | 'manual' | 'webapp'>('webapp');
  const [url, setUrl] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    setLoading(true);
    setError('');

    try {
      await addDoc(collection(db, 'projects'), {
        title,
        description,
        type,
        url: url || null,
        imageUrl: imageUrl || null,
        authorId: currentUser.uid,
        authorName: currentUser.displayName || 'Аноним',
        authorPhoto: currentUser.photoURL || null,
        likes: [],
        commentCount: 0,
        createdAt: serverTimestamp()
      });

      onClose();
    } catch (err: any) {
      console.error(err);
      setError('Ошибка при создании проекта');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-gradient-to-br from-purple-900 to-indigo-900 rounded-3xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-white/20">
        <div className="sticky top-0 bg-gradient-to-r from-purple-900 to-indigo-900 p-6 border-b border-white/20 flex items-center justify-between">
          <h2 className="text-2xl font-bold text-white">Новый проект</h2>
          <button
            onClick={onClose}
            className="text-white hover:text-red-400 transition-colors"
          >
            <FaTimes className="text-2xl" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div>
            <label className="block text-white font-semibold mb-2">Название проекта</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-white/10 border border-white/20 rounded-xl py-3 px-4 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
              placeholder="Введите название..."
              required
            />
          </div>

          <div>
            <label className="block text-white font-semibold mb-2">Описание</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-white/10 border border-white/20 rounded-xl py-3 px-4 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500 h-32 resize-none"
              placeholder="Расскажите о вашем проекте..."
              required
            />
          </div>

          <div>
            <label className="block text-white font-semibold mb-3">Тип проекта</label>
            <div className="grid grid-cols-3 gap-3">
              <button
                type="button"
                onClick={() => setType('ai')}
                className={`p-4 rounded-xl border-2 transition-all ${
                  type === 'ai'
                    ? 'border-purple-500 bg-purple-500/30'
                    : 'border-white/20 bg-white/5 hover:bg-white/10'
                }`}
              >
                <FaRobot className="text-3xl text-white mx-auto mb-2" />
                <p className="text-white font-semibold">AI проект</p>
              </button>

              <button
                type="button"
                onClick={() => setType('manual')}
                className={`p-4 rounded-xl border-2 transition-all ${
                  type === 'manual'
                    ? 'border-purple-500 bg-purple-500/30'
                    : 'border-white/20 bg-white/5 hover:bg-white/10'
                }`}
              >
                <FaCode className="text-3xl text-white mx-auto mb-2" />
                <p className="text-white font-semibold">Ручной код</p>
              </button>

              <button
                type="button"
                onClick={() => setType('webapp')}
                className={`p-4 rounded-xl border-2 transition-all ${
                  type === 'webapp'
                    ? 'border-purple-500 bg-purple-500/30'
                    : 'border-white/20 bg-white/5 hover:bg-white/10'
                }`}
              >
                <FaGlobe className="text-3xl text-white mx-auto mb-2" />
                <p className="text-white font-semibold">Веб-сайт</p>
              </button>
            </div>
          </div>

          <div>
            <label className="block text-white font-semibold mb-2">URL проекта (опционально)</label>
            <input
              type="url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              className="w-full bg-white/10 border border-white/20 rounded-xl py-3 px-4 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
              placeholder="https://example.com"
            />
          </div>

          <div>
            <label className="block text-white font-semibold mb-2">URL изображения (опционально)</label>
            <input
              type="url"
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              className="w-full bg-white/10 border border-white/20 rounded-xl py-3 px-4 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
              placeholder="https://example.com/image.png"
            />
          </div>

          {error && (
            <div className="bg-red-500/20 border border-red-500/50 rounded-xl p-3 text-red-200">
              {error}
            </div>
          )}

          <div className="flex space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 bg-white/10 text-white py-3 rounded-xl font-semibold hover:bg-white/20 transition-all border border-white/20"
            >
              Отмена
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 bg-gradient-to-r from-purple-500 to-indigo-500 text-white py-3 rounded-xl font-semibold hover:from-purple-600 hover:to-indigo-600 transition-all shadow-lg disabled:opacity-50"
            >
              {loading ? 'Создание...' : 'Создать проект'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
